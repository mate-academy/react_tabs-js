export const Tabs = () => {};
